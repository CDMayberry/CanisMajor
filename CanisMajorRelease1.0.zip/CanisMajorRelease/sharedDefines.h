//Defines shared with the HLSL because both languages use the same syntax for it.

#define MAX_LIGHTS 4